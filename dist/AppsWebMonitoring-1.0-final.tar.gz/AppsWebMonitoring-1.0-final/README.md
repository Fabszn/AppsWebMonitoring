AppsWebMonitoring
=================

This project's aim is to provide service to monitoring some web applications.

How install it?
=================

Setup is very simply. Download current version from dist directory.

Unpack archive and run the following command : java -jar AppsWebMonitoring.xxxx.jar params
